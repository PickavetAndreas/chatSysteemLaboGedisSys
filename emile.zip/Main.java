import java.io.IOException;

public class Main {
    public static void main(String[] args) throws IOException {
        Client c = new Client();
        c.runClient();
        Client oi = new Client();
        oi.runClient();
    }
}